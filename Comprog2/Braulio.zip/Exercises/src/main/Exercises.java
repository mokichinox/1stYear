/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import java.util.Scanner;

/**
 *
 * @author avdbraulio
 */
public class Exercises {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      String name;
      int age;
      String hobby;
      
      Scanner myObj = new Scanner(System.in);
      System.out.print("Please enter your name: ");
      name = myObj.nextLine();
      System.out.print("Please enter your age: ");
      age = myObj.nextInt();
      myObj.nextLine();
      System.out.print("Please enter your hobby: ");
      hobby = myObj.nextLine();
      System.out.println("Hi my name is " + name + " and I am " + age + " years old. My hobby is " + hobby + ".");
        
        
    }
    
}
