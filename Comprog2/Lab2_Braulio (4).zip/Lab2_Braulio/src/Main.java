import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
      

        int i = 1;
        int totalUnits = 0;
        float totalGrade = 0;
        

        System.out.println("Welcome to QPI Calculator!\n");

        while (i <= 3) {
            Scanner sc = new Scanner(System.in);
            
  
            System.out.printf("Enter your grade: ");
            float grade = sc.nextFloat();
            
            System.out.printf("Enter your units: ");
            int units = sc.nextInt();
            sc.nextLine();
            System.out.print('\n');
            

            totalGrade += grade * units;
            totalUnits += units;
            i++;
        } 

        float qpi = totalGrade / totalUnits;

        System.out.printf("Your QPI is: %.2f%n", qpi);
    
    
    /*QPI = (Sum(Numerical Grade * Units))/sum of units

        Create a QPI calculator that will calculate grades 
        for 3 subjects. Output must be in 2 decimal places.*/
        

    }
    
}